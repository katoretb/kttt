const TicTacToe = require('discord-tictactoe');
const Discord = require('discord.js');
const yourBot = new Discord.Client();

new TicTacToe({
  language: 'th',
  command: '=ttt'
}, yourBot);

yourBot.login('NzYyNjkzNzUwODIwMTc1OTIz.X3s36A.ysen8Th4wqvSHSCNipOl2S19jlE');